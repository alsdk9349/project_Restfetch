using Pathfinding;
using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using Priority_Queue;
using static UnityEditor.ShaderGraph.Internal.KeywordDependentCollection;

public class GameManager : MonoBehaviour
{
    public static GameManager instance;
    //public QuadTree quadTree;
    public GameObject LineRendererList;
    public GameObject SLAMCamera;
    public GameObject SLAMBody;
    public ParseJson parseJson;
    public GridGraph gridGraph;
    public Vector3 goalPosition;
    public RobotMode robotMode;
    public Node<Vector3> startNode;
    public Node<Vector3> goalNode;
    public int initCnt = 0;
    public bool getDataState;
    public bool completeCommand;
    public bool getNewData;
    public bool makeNewCommand;
    public bool isCommanding = false;
    public float map_x = 100f;  // map x �� ���� ��ġ
    public float map_z = 0f;    // map z �� ���� ��ġ
    public float width_s = 60f; // ���� x �� ������ 3��
    public float height_s = 100f;   // ���� z �� ������ 3��

    private void Awake()
    {

    }


    // Start is called before the first frame update
    void Start()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        Rect rect = GetRect(map_x, map_z, width_s, height_s);
        //quadTree = new QuadTree(0, rect);
        RobotMode robotMode = new RobotMode();
        goalPosition = new Vector3();

        // 1. �׷��� ����
        gridGraph = new GridGraph();
        gridGraph.CreateGraph(600, 1000, 8, transform.position);

        getDataState = true;
        getNewData = false;
        makeNewCommand = false;
        completeCommand = false;
        parseJson = new ParseJson();
    }

    //public FastPriorityQueue<Node<Vector3>> que = new FastPriorityQueue<Node<Vector3>>(100);
    // Update is called once per frame
    void Update()
    {
        //Debug.Log(getDataState + " " + getNewData + " " + completeCommand + " " + makeNewCommand);

        if(getNewData)
        {
            getNewData = false;
            makeNewCommand = true;
            goalPosition = new Vector3(parseJson.data.latitude, 0,  parseJson.data.longitude);
        }
    }

    public Rect GetRect(float x, float y, float width, float height)
    {
        Rect returnRect = new Rect(x, y, width, height);

        return returnRect;
    }

    public void MoveSLAM(Vector2 nextPos)
    {

    }

    public IEnumerator WaitAndDoSomething(float timer)
    {
        //Debug.Log("3�� ��� ����");

        yield return new WaitForSeconds(timer);

        //Debug.Log("3�� ��� �� ����");
    }
}

public class QuadTree
{
    private int level;         // Ʈ���� ����
    private int maxLevel = 4;
    private Rect bounds;       // QuadTree�� Ŀ���ϴ� 2D ����
    private List<LineRenderer> points; // ����� �� ����Ʈ
    private QuadTree[] nodes;  // �ڽ� ��� (�ִ� 4��)

    public QuadTree(int level, Rect bounds)
    {
        this.level = level;
        this.bounds = bounds;
        points = new List<LineRenderer>();
        nodes = new QuadTree[4];
    }

    // �ڽ� ���� �����ϴ� �Լ�
    private void Split()
    {
        float subWidth = bounds.width / 2f;
        float subHeight = bounds.height / 2f;
        float x = bounds.x;
        float y = bounds.y;

        nodes[0] = new QuadTree(level + 1, new Rect(x + subWidth, y, subWidth, subHeight)); // ���� ���
        nodes[1] = new QuadTree(level + 1, new Rect(x, y, subWidth, subHeight));            // ���� ���
        nodes[2] = new QuadTree(level + 1, new Rect(x, y + subHeight, subWidth, subHeight));// ���� �ϴ�
        nodes[3] = new QuadTree(level + 1, new Rect(x + subWidth, y + subHeight, subWidth, subHeight)); // ���� �ϴ�
    }

    // ���� �����ϴ� �Լ�
    public void Insert(LineRenderer point)
    {
        // ���� ��忡 ���Ե��� ������ ����
        if (!bounds.Contains(new Vector2(point.transform.position.x, point.transform.position.z)))
            return;

        if (level >= maxLevel)
        {
            points.Add(point);
            return;
        }

        // �ڽ� ��尡 ������ ����
        if (nodes[0] == null)
        {
            Split();
        }

        // �ڽ� ��� �� ������ ���� �� ����
        for (int i = 0; i < 4; i++)
        {
            nodes[i].Insert(point);
        }
    }

    // Ư�� ���� ���� ���� �˻��ϴ� �Լ�
    public List<LineRenderer> Retrieve(List<LineRenderer> returnPoints, Rect searchArea)
    {
        // �˻� ������ ���� ���� �������� ������ ��ȯ
        if (!bounds.Overlaps(searchArea))
            return returnPoints;

        // ���� ����� ���� �߰�
        foreach (LineRenderer point in points)
        {
            if (searchArea.Contains(new Vector2(point.transform.position.x, point.transform.position.z)))
            {
                returnPoints.Add(point);
            }
        }

        // �ڽ� ��尡 �ִ� ��� �ڽ� ��忡���� �˻�
        if (nodes[0] != null)
        {
            for (int i = 0; i < 4; i++)
            {
                nodes[i].Retrieve(returnPoints, searchArea);
            }
        }

        return returnPoints;
    }

    // QuadTree�� �ð������� �׸��� �Լ� (������)
    public void Draw()
    {
        // ���� ����� ��踦 �׸��ϴ�
        //Debug.DrawLine(new Vector3(bounds.x, bounds.y, 0), new Vector3(bounds.x + bounds.width, bounds.y, 0), Color.green);
        //Debug.DrawLine(new Vector3(bounds.x, bounds.y, 0), new Vector3(bounds.x, bounds.y + bounds.height, 0), Color.green);
        //Debug.DrawLine(new Vector3(bounds.x + bounds.width, bounds.y, 0), new Vector3(bounds.x + bounds.width, bounds.y + bounds.height, 0), Color.green);
        //Debug.DrawLine(new Vector3(bounds.x, bounds.y + bounds.height, 0), new Vector3(bounds.x + bounds.width, bounds.y + bounds.height, 0), Color.green);

        // �ڽ� ��尡 ������ �ڽ� ��嵵 �׸��ϴ�
        if (nodes[0] != null)
        {
            for (int i = 0; i < 4; i++)
            {
                nodes[i].Draw();
            }
        }
    }
}

public enum RobotMode
{
    Init,
    GetCommand,
    SLAMMode,
    NavigationMode,
    LocalNavigationMode,

}

public enum NodeState
{
    New,
    Open,
    Closed
}

public class GridGraph
{
    public List<Node<Vector3>> allNodes = new List<Node<Vector3>>();
    public int gridSizeX, gridSizeY, halfGridSizeX, halfGridSizeY;
    public float nodeSize;
    public float inverseNodeSize;
    public Vector3 adjustedRobotPos;
    public Node<Vector3>[,] nodes;

    public void CreateGraph(int gridSizeX, int gridSizeY, float nodeSize, Vector3 robotPos)
    {
        nodes = new Node<Vector3>[gridSizeX, gridSizeY];
        this.gridSizeX = gridSizeX;
        this.gridSizeY = gridSizeY;
        this.nodeSize = nodeSize;
        inverseNodeSize = 1 / nodeSize;
        halfGridSizeX = gridSizeX >> 1;
        halfGridSizeY = gridSizeY >> 1;
        adjustedRobotPos = new Vector3(-robotPos.x * nodeSize + (float)halfGridSizeX, 0, -robotPos.z * nodeSize + (float)halfGridSizeY);
        Vector3 worldBottomLeft = new Vector3(gridSizeX / 2f, 0, gridSizeY / 2f) * nodeSize;
        //Debug.Log("����" + halfGridSizeX + " " + halfGridSizeY);
        //Debug.Log(adjustedRobotPos.x + " " + adjustedRobotPos.z);

        for (int x = 0; x < gridSizeX; x++)
        {
            for (int y = 0; y < gridSizeY; y++)
            {
                //Vector3 worldPoint = worldBottomLeft + new Vector3(x * nodeSize, 0, y * nodeSize);
                Vector3 worldPoint = new Vector3((x - adjustedRobotPos.x) * inverseNodeSize, 0, (y - adjustedRobotPos.z) * inverseNodeSize);
                bool isWalkable = !Physics.CheckSphere(worldPoint, inverseNodeSize / 2 , LayerMask.GetMask("Obstacle"));

                if (isWalkable)
                {
                    Node<Vector3> node = new Node<Vector3>(
                        worldPoint,
                        (a, b) => {
                            if (a.isObstacle || b.isObstacle) return float.MaxValue;
                            else
                                return Vector3.Distance(a.Data, b.Data);
                        }, // ��� �Լ�
                        (a, b) => Vector3.Distance(a.Data, b.Data)  // �޸���ƽ �Լ�
                    );

                    nodes[x, y] = node;
                    allNodes.Add(node);
                    //Debug.Log("AllNodes �߰�");
                }
            }
        }

        // ��� ���� ���� ����
        for (int x = 0; x < gridSizeX; x++)
        {
            for (int y = 0; y < gridSizeY; y++)
            {
                Node<Vector3> node = nodes[x, y];
                if (node != null)
                {
                    List<Node<Vector3>> neighbors = new List<Node<Vector3>>();

                    // ������ 8���� ��� Ȯ��
                    for (int dx = -1; dx <= 1; dx++)
                    {
                        for (int dy = -1; dy <= 1; dy++)
                        {
                            if (dx == 0 && dy == 0)
                                continue;

                            int checkX = x + dx;
                            int checkY = y + dy;

                            if (checkX >= 0 && checkX < gridSizeX && checkY >= 0 && checkY < gridSizeY)
                            {
                                Node<Vector3> neighbor = nodes[checkX, checkY];
                                if (neighbor != null)
                                {
                                    neighbors.Add(neighbor);
                                }
                            }
                        }
                    }

                    node.Neighbors = neighbors;
                }
            }
        }
    }

    public Node<Vector3> GetNearestNode(Vector3 position)
    {
        // ��ġ�� ���� ����� ��带 ��ȯ�մϴ�.
        float minDistance = Mathf.Infinity;
        Node<Vector3> nearestNode = null;

        //foreach (var node in allNodes)
        //{
        //    float distance = Vector3.Distance(position, node.Data);
        //    if (distance < minDistance)
        //    {
        //        minDistance = distance;
        //        nearestNode = node;
        //    }
        //}

        Vector3Int pos = worldDistanceToIndex(position);
        //Debug.Log(position);
        //Debug.Log(pos);
        nearestNode = nodes[pos.x, pos.z];
        //Debug.Log(nearestNode);

        return nearestNode;
    }

    // Index -> WorldPoint
    public Vector3 indexToWorldDistance(Vector3 index)
    {
        Vector3 vector3 = new Vector3((index[0] - adjustedRobotPos[0]) * inverseNodeSize, 0, (index[2] - adjustedRobotPos[2]) * inverseNodeSize);
        return vector3;
    }

    // WorldPoint -> Index
    public Vector3Int worldDistanceToIndex(Vector3 distance)
    {
        Vector3Int vector3 = new Vector3Int(Mathf.FloorToInt(distance[0] * nodeSize + adjustedRobotPos[0]), 0, Mathf.FloorToInt(distance[2] * nodeSize + adjustedRobotPos[2]));
        return vector3;
    }
}

[System.Serializable]
public class ParseJson
{
    public int status;
    public string code;
    public string message;
    public DataJson data;

    public void printf()
    {
        //Debug.Log("statusFirst : " + status);
        //Debug.Log("codeFirst : " + code);
        //Debug.Log("messageFirst : " + message);
        //Debug.Log("dataFirst : " + data);
    }
}

[System.Serializable]
public class DataJson
{
    public int pickId;
    public int reportId;
    public int observerId;
    public string observerSerialNumber;
    public float latitude;
    public float longitude;
}




















































// DStarLite ����
//public class DStarLite
//{
//    private GridNode startNode;
//    private GridNode goalNode;
//    private PriorityQueue<GridNode> openList;
//    private HashSet<GridNode> closedList;
//    private Dictionary<GridNode, float> rhs;
//    private Dictionary<GridNode, float> g;

//    public DStarLite(GridNode start, GridNode goal)
//    {
//        startNode = start;
//        goalNode = goal;
//        openList = new PriorityQueue<GridNode>();
//        closedList = new HashSet<GridNode>();
//        rhs = new Dictionary<GridNode, float>();
//        g = new Dictionary<GridNode, float>();

//        rhs[goalNode] = 0;
//        g[goalNode] = float.PositiveInfinity;
//        openList.Enqueue(goalNode, CalculateKey(goalNode));
//    }

//    private float CalculateKey(GridNode node)
//    {
//        float minCost = Math.Min(g.ContainsKey(node) ? g[node] : float.PositiveInfinity, rhs.ContainsKey(node) ? rhs[node] : float.PositiveInfinity);
//        return minCost + Heuristic(startNode, node);
//    }

//    private float Heuristic(GridNode a, GridNode b)
//    {
//        // ����ư �Ÿ� ���
//        return Math.Abs(a.x - b.x) + Math.Abs(a.y - b.y);
//    }

//    public void ComputeShortestPath()
//    {
//        while (openList.Count > 0 &&
//               (g.ContainsKey(startNode) ? g[startNode] : float.PositiveInfinity) !=
//               (rhs.ContainsKey(startNode) ? rhs[startNode] : float.PositiveInfinity))
//        {
//            GridNode u = openList.Dequeue();
//            closedList.Add(u);

//            if (g.ContainsKey(u) && g[u] > (rhs.ContainsKey(u) ? rhs[u] : float.PositiveInfinity))
//            {
//                g[u] = rhs[u];
//                foreach (GridNode s in GetPredecessors(u))
//                {
//                    UpdateVertex(s);
//                }
//            }
//            else
//            {
//                g[u] = float.PositiveInfinity;
//                UpdateVertex(u);
//                foreach (GridNode s in GetPredecessors(u))
//                {
//                    UpdateVertex(s);
//                }
//            }
//        }
//    }

//    private void UpdateVertex(GridNode u)
//    {
//        if (u != goalNode)
//        {
//            rhs[u] = float.PositiveInfinity;
//            foreach (GridNode s in GetSuccessors(u))
//            {
//                float temp = (g.ContainsKey(s) ? g[s] : float.PositiveInfinity) + Cost(u, s);
//                if (rhs[u] > temp)
//                {
//                    rhs[u] = temp;
//                }
//            }
//        }

//        openList.Enqueue(u, CalculateKey(u));
//    }

//    private float Cost(GridNode a, GridNode b)
//    {
//        if (!b.isWalkable)
//            return float.PositiveInfinity;
//        return 1; // ������ ��� ������ �⺻ ���
//    }

//    private IEnumerable<GridNode> GetPredecessors(GridNode node)
//    {
//        // ����� ���� ������ ��ȯ
//        return GetNeighbors(node);
//    }

//    private IEnumerable<GridNode> GetSuccessors(GridNode node)
//    {
//        // ����� ���� ������ ��ȯ
//        return GetNeighbors(node);
//    }

//    private List<GridNode> GetNeighbors(GridNode node)
//    {
//        // �׸��� ��� �̿� ��� ��ȯ
//        List<GridNode> neighbors = new List<GridNode>();
//        // �ڵ� �ۼ� �ʿ�
//        return neighbors;
//    }

//    public List<GridNode> GetPath()
//    {
//        List<GridNode> path = new List<GridNode>();
//        GridNode current = startNode;

//        if (!g.ContainsKey(current) || g[current] == float.PositiveInfinity)
//            return null; // ��� ����

//        while (current != goalNode)
//        {
//            path.Add(current);
//            GridNode next = null;
//            float minCost = float.PositiveInfinity;

//            foreach (GridNode s in GetSuccessors(current))
//            {
//                float cost = Cost(current, s) + (g.ContainsKey(s) ? g[s] : float.PositiveInfinity);
//                if (cost < minCost)
//                {
//                    minCost = cost;
//                    next = s;
//                }
//            }

//            if (next == null)
//                return null; // ��� ����

//            current = next;
//        }

//        path.Add(goalNode);
//        return path;
//    }
//}

//public class GridNode
//{
//    public int x;
//    public int y;
//    public bool isWalkable;
//    public float gCost;
//    public float hCost;
//    public float fCost => gCost + hCost;
//    public GridNode parent;

//    public GridNode(int x, int y, bool isWalkable)
//    {
//        this.x = x;
//        this.y = y;
//        this.isWalkable = isWalkable;
//    }
//}

// PQ Ŀ���� ����
//public class PriorityQueue<T> where T : IComparable<T>
//{
//    private List<T> data;

//    public PriorityQueue()
//    {
//        this.data = new List<T>();
//    }

//    public void Enqueue(T item)
//    {
//        data.Add(item);
//        int ci = data.Count - 1; // child index
//        while (ci > 0)
//        {
//            int pi = (ci - 1) / 2; // parent index
//            if (data[ci].CompareTo(data[pi]) >= 0)
//                break;
//            T tmp = data[ci]; data[ci] = data[pi]; data[pi] = tmp;
//            ci = pi;
//        }
//    }

//    public T Dequeue()
//    {
//        int li = data.Count - 1; // last index
//        T frontItem = data[0];
//        data[0] = data[li];
//        data.RemoveAt(li);

//        --li;
//        int pi = 0; // parent index
//        while (true)
//        {
//            int ci = pi * 2 + 1; // left child index
//            if (ci > li)
//                break;
//            int rc = ci + 1; // right child index
//            if (rc <= li && data[rc].CompareTo(data[ci]) < 0)
//                ci = rc;
//            if (data[pi].CompareTo(data[ci]) <= 0)
//                break;
//            T tmp = data[pi]; data[pi] = data[ci]; data[ci] = tmp;
//            pi = ci;
//        }

//        return frontItem;
//    }

//    public int Count()
//    {
//        return data.Count;
//    }
//}

// ����
//unsafe struct PathStorageLinkedList
//{
//    public Vector2* prev;
//    public Vector2* now;
//    public PathStorageLinkedList** next;

//    public PathStorageLinkedList(int size) {
//        next = (PathStorageLinkedList**)Marshal.AllocHGlobal(sizeof(PathStorageLinkedList*) * 8);
//        prev = null;
//        now = null;
//    }

//    public void Dispose()
//    {
//        for (int i = 0; i < 8; i++)
//        {
//            if (next[i] != null)
//            {
//                Marshal.FreeHGlobal((System.IntPtr)next[i]);
//                next[i] = null;
//            }
//        }

//        if (prev != null)
//        {
//            Marshal.FreeHGlobal((System.IntPtr)prev);
//            prev = null;
//        }
//    }
//}

//unsafe class LinkedListManager
//{
//    public PathStorageLinkedList* head;
//    public PathStorageLinkedList* now;

//    public LinkedListManager()
//    {
//        head = null;
//        now = null;
//    }

//    public void AddNode(int dir, Vector2* nowPos, Vector2** nextPos)
//    {
//        PathStorageLinkedList* newNode = (PathStorageLinkedList*)Marshal.AllocHGlobal(sizeof(PathStorageLinkedList));

//        *newNode = new PathStorageLinkedList(0);
//        newNode->now = nowPos;

//        for(int i = 0; i < 8; i++)
//        {
//            newNode->next[i]->now = nextPos[i];
//            newNode->next[i]->prev = nowPos;
//        }

//        if(head == null)
//        {
//            head = newNode;
//            now = newNode;
//            now->prev = null;
//        } else
//        {
//            now->next[dir] = newNode;
//            now = newNode;
//        }
//    }

//    public void MoveNode(Rigidbody robotRigidBody, Animator anim, float moveSpeed)
//    {
//        Vector3 moveDirection = transform.forward * moveSpeed * Time.fixedDeltaTime;
//        robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);
//        anim.SetBool("Walk_Anim", true);

//        for (int i = 0; i < 8; i++)
//        {
//            if (now->next[i] == null) continue;
//            Vector3 modeDirection = new Vector3(now->next[i]->now->x, 0, now->next[i]->now->y).normalized * moveSpeed * Time.fixedDeltaTime;
//            robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);
//            anim.SetBool("Walk_Anim", true);

//            while(true)
//            {
//                if ((int)robotRigidBody.position.x == (int)now->next[i]->now->x && (int)robotRigidBody.position.z == (int)now->next[i]->now->y) break;
//            }

//            return;
//        }

//        if(now->prev != null)
//        {
//            Vector3 modeDirection = new Vector3(robotRigidBody.position.x - now->prev->x, 0,robotRigidBody.position.z - now->prev->y).normalized * moveSpeed * Time.fixedDeltaTime;
//            robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);
//            anim.SetBool("Walk_Anim", true);
//        }
//    }

//    public void DisposeAllNodes(PathStorageLinkedList* node)
//    {
//        if (node == null) return;

//        for(int i = 0; i < 8; i++)
//        {
//            if (node->next[i] != null)
//            {
//                DisposeAllNodes(node->next[i]);
//            }
//        }

//        node->Dispose();
//        Marshal.FreeHGlobal((System.IntPtr)node);
//    }
//}