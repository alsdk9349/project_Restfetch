using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using UnityEditor.Experimental.GraphView;
using static UnityEngine.GraphicsBuffer;
using System;

public class Robot : MonoBehaviour
{
    private int currentPathIndex = 0;
    private float speed = 0.5f;
    private float rotSpeed = 80f;
    private float moveSpeed = 0.00000001f;
    public GameObject attachedObject = null;
    public float detectionRange = 0.1f;
    public bool goalin;

    private Vector3 rot = Vector3.zero;
    private Vector3 offset = new Vector3(130, 15, 50);
    public DStarLite<Vector3> dStarLite;
    public List<Node<Vector3>> path;
    public Transform SLAMBody;
    public GameObject targetObject;
    public Animator anim;
    private Rigidbody robotRigidBody;
    private string transformationStateName = "anim_open";

    void Start()
    {
        // D* Lite �˰����� �ʱ�ȭ
        // ...
        robotRigidBody = GetComponent<Rigidbody>();

        offset += robotRigidBody.transform.forward;
        SLAMBody.position = robotRigidBody.transform.position + offset;
        goalin = false;
    }

    int cnt = 0;
    void Update()
    {
        if (anim.GetCurrentAnimatorStateInfo(0).IsName(transformationStateName))
        {
            return;
        }

        //Debug.Log(anim.GetCurrentAnimatorStateInfo(0).IsName(transformationStateName));
        //Debug.Log("���� �����");
        if (GameManager.instance.makeNewCommand)
        {
            GameManager.instance.makeNewCommand = false;
            GameManager.instance.startNode = GameManager.instance.gridGraph.GetNearestNode(transform.position);
            GameManager.instance.goalNode = GameManager.instance.gridGraph.GetNearestNode(GameManager.instance.goalPosition);

            // dStarLite ���� �� �ʱ�ȭ
            dStarLite = new DStarLite<Vector3>(GameManager.instance.startNode, GameManager.instance.goalNode, GameManager.instance.gridGraph.allNodes);
            dStarLite.Initialize();

            // 4. ���� ��� ���
            dStarLite.ComputeShortestPath();
            path = dStarLite.GetPath();
            currentPathIndex = 0;
            //Debug.Log("���� ����� makeNewcommand");
        }

        if (GameManager.instance.isCommanding && !goalin)
        {
            // ��θ� ���� �̵�
            MoveAlongPath();
        }

        if(goalin)
        {
            MoveBackAlong();
        }

        // ��ֹ� ���� �� ó��
        if (false)//IsObstacleDetected())
        {
            Vector3 obstaclePosition = transform.position + transform.forward * detectionRange;
            UpdateMap(obstaclePosition);

            Node<Vector3> currentNode = GameManager.instance.gridGraph.GetNearestNode(transform.position);
            if (currentNode != dStarLite.startNode)
            {
                dStarLite.UpdateStart(currentNode);
                dStarLite.ComputeShortestPath();

                // ��� ��������
                path = dStarLite.GetPath();
                currentPathIndex = 0;
            }

            // ��� ���ȹ
            dStarLite.RecalculateNode(GameManager.instance.gridGraph.GetNearestNode(obstaclePosition));

            // ���ο� ��� ��������
            path = dStarLite.GetPath();
            currentPathIndex = 0;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.layer == LayerMask.NameToLayer("Things"))
        {
            // �浹�� ��ü�� ����
            attachedObject = collision.gameObject;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject == attachedObject)
        {
            // �浹�� ������ ��ü ����
            attachedObject = null;
        }
    }


    bool IsObstacleDetected()
    {
        // ������ ����Ͽ� ��ֹ� ����
        RaycastHit hit;
        //Debug.DrawRay(transform.position, transform.forward * detectionRange, Color.green);
        //Debug.Log(transform.position);
        if (Physics.Raycast(transform.position, transform.forward, out hit, detectionRange))
        {
            // ��ֹ��� ������
            //Debug.Log("��ֹ� ������" + hit.collider.name);
            return true;
        }
        return false;
    }

    void UpdateMap(Vector3 obstaclePosition)
    {
        Node<Vector3> obstacleNode = GameManager.instance.gridGraph.GetNearestNode(obstaclePosition);

        if (obstacleNode != null && !obstacleNode.isObstacle)
        {
            obstacleNode.isObstacle = true;

            // D* Lite �˰����� ��ֹ� ���� ������Ʈ
            dStarLite.RecalculateNode(obstacleNode);
        }
    }

    void MoveBackAlong()
    {
        if (path == null)
        {
            //Debug.Log("return ��" + path.Count);
            anim.SetBool("Walk_Anim", false);
            return;
        }

        if (currentPathIndex <= 0)
        {
            anim.SetBool("Walk_Anim", false);
            GameManager.instance.completeCommand = true;
            GameManager.instance.isCommanding = false;
            goalin = false;

            return;
        }

        attachedObject.transform.position = transform.position;
        attachedObject.transform.rotation = transform.rotation;
        Node<Vector3> targetNode = path[currentPathIndex - 1];
        Vector3 targetPosition = targetNode.Data;

        // �κ� �̵� ����
        Vector3 direction = (robotRigidBody.position - targetNode.Data).normalized;
        Vector3 moveDirection = direction * moveSpeed * Time.fixedDeltaTime;
        robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);

        if (direction != Vector3.zero)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.fixedDeltaTime);

            // ��ǥ�� �ٶ󺸵��� ȸ��
            transform.LookAt(targetPosition);
            //Debug.Log("���� ��");
        }
        // �κ� �̵� ����
        // Vector3 direction = (targetPosition - transform.position).normalized;

        //transform.position += direction * speed * Time.deltaTime;
        SLAMBody.position = robotRigidBody.transform.position + offset;
        anim.SetBool("Walk_Anim", true);

        //Debug.Log(targetNode.Data + " ");

        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            currentPathIndex--;
        }
    }

    void MoveAlongPath()
    {
        if (path == null)
        {
            //Debug.Log("return ��" + path.Count);
            anim.SetBool("Walk_Anim", false);
            return;
        }

        if (currentPathIndex >= path.Count)
        {
            goalin = true;
            return;
        }

        Node<Vector3> targetNode = path[currentPathIndex];
        Vector3 targetPosition = targetNode.Data;

        // �κ� �̵� ����
        Vector3 direction = (robotRigidBody.position - targetNode.Data).normalized;
        Vector3 moveDirection = direction * moveSpeed * Time.fixedDeltaTime;
        robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);

        if (direction != Vector3.zero)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.fixedDeltaTime);

            // ��ǥ�� �ٶ󺸵��� ȸ��
            transform.LookAt(targetPosition);
            //Debug.Log("���� ��");
        }
        // �κ� �̵� ����
        // Vector3 direction = (targetPosition - transform.position).normalized;

        //transform.position += direction * speed * Time.deltaTime;
        SLAMBody.position = robotRigidBody.transform.position + offset;
        anim.SetBool("Walk_Anim", true);

        //Debug.Log(targetNode.Data + " ");

        if (Vector3.Distance(transform.position, targetPosition) < 0.1f)
        {
            currentPathIndex++;
        }
    }
}

//public class Robot : MonoBehaviour
//{

//    Vector3 rot = Vector3.zero;
//    Vector3 offset = new Vector3(130, 15, 50);
//    float rotSpeed = 40f;
//    float moveSpeed = 1f;
//    Animator anim;
//    Rigidbody robotRigidBody;
//    public Transform SLAMBody;

//    void Start()
//    {
//        robotRigidBody = GetComponent<Rigidbody>();
//        offset += robotRigidBody.transform.forward;
//        SLAMBody.position = robotRigidBody.transform.position + offset;
//    }

//    // Use this for initialization
//    void Awake()
//    {
//        anim = gameObject.GetComponent<Animator>();
//        gameObject.transform.eulerAngles = rot;
//    }

//    // Update is called once per frame
//    void FixedUpdate()
//    {
//        CheckKey();

//    }

//    private void Update()
//    {

//    }

//    void CheckKey()
//    {
//        // Walk
//        if (Input.GetKey(KeyCode.W))
//        {
//            // gameObject.transform.Translate(direction * rotSpeed * Time.fixedDeltaTime, gameObject.transform);
//            Vector3 moveDirection = transform.forward * moveSpeed * Time.fixedDeltaTime;
//            robotRigidBody.MovePosition(robotRigidBody.position + moveDirection);
//            SLAMBody.position = robotRigidBody.transform.position + offset;
//            anim.SetBool("Walk_Anim", true);
//        }
//        //else if (Input.GetKeyUp(KeyCode.W))
//        //{
//        //          anim.SetBool("Walk_Anim", false);
//        //}
//        else
//        {
//            anim.SetBool("Walk_Anim", false);
//        }

//        // Rotate Left
//        if (Input.GetKey(KeyCode.A))
//        {
//            rot[1] -= rotSpeed * Time.fixedDeltaTime; gameObject.transform.eulerAngles = rot;
//        }

//        // Rotate Right
//        if (Input.GetKey(KeyCode.D))
//        {
//            rot[1] += rotSpeed * Time.fixedDeltaTime; gameObject.transform.eulerAngles = rot;
//        }

//        // Roll
//        if (Input.GetKeyDown(KeyCode.Space))
//        {
//            if (anim.GetBool("Roll_Anim"))
//            {
//                anim.SetBool("Roll_Anim", false);
//            }
//            else
//            {
//                anim.SetBool("Roll_Anim", true);
//            }
//        }

//        // Close
//        if (Input.GetKeyDown(KeyCode.LeftControl))
//        {
//            if (!anim.GetBool("Open_Anim"))
//            {
//                anim.SetBool("Open_Anim", true);
//            }
//            else
//            {
//                anim.SetBool("Open_Anim", false);
//            }
//        }
//    }
//    // ȸ�� ����
//}
