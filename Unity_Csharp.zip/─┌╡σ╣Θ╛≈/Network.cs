using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using Newtonsoft.Json;
using Pathfinding;
using UnityEngine;

public class Network : MonoBehaviour
{
    public static Network instance;
    NetworkNode node;

    private void Start()
    {
        node = new NetworkNode();

        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    async void Update()
    {
        //Debug.Log("trtwetqert " + node + " " + GameManager.instance.getDataState + " " + GameManager.instance.completeCommand + " " + GameManager.instance.isCommanding);
        if (node != null && GameManager.instance.getDataState && !GameManager.instance.isCommanding)
        {
            GameManager.instance.getDataState = false;
            Debug.Log("Post ��û");
            // HTTP POST ��û ������
            await SendPostRequest();
            //StartCoroutine(GameManager.instance.WaitAndDoSomething(3));
        }

        //Debug.Log(GameManager.instance.parseJson + " " + GameManager.instance.parseJson.data);
        if (GameManager.instance.parseJson.data != null && GameManager.instance.parseJson.data.reportId != 0 && GameManager.instance.completeCommand)
        {
            GameManager.instance.isCommanding = false;
            GameManager.instance.completeCommand = false;
            //Debug.Log("command false�� ��ȯ");
            await SendPostCompleteRequest();
        }
    }

    public async Task SendPostRequest()
    {
        using (HttpClient client = new HttpClient())
        {
            //Debug.Log("SendPostRequest");
            try
            {
                // POST ��û ������
                HttpResponseMessage response = await client.PostAsync(node.url, node.content);
                //Debug.Log("����");
                // ��û ���� ���� Ȯ��
                if (response.IsSuccessStatusCode)
                {
                    // ���� ���� �б�
                    GameManager.instance.isCommanding = true;
                    string responseBody = await response.Content.ReadAsStringAsync();

                    if (GameManager.instance == null)
                    {
                        //Debug.LogError("GameManager instnace is null!");
                        return;
                    }

                    GameManager.instance.parseJson = JsonUtility.FromJson<ParseJson>(responseBody);

                    if (GameManager.instance.parseJson == null)
                    {
                        //Debug.LogError("Failed to parse JSON.");
                        return;
                    }

                    GameManager.instance.getNewData = true;

                    // 2. ���� ���� ��ǥ ��� ����
                    //Debug.Log("statusFirst : " + GameManager.instance.parseJson.status);
                    //Debug.Log("codeFirst : " + GameManager.instance.parseJson.code);
                    //Debug.Log("messageFirst : " + GameManager.instance.parseJson.message);
                    //Debug.Log("dataFirst : " + GameManager.instance.parseJson.data.reportId);
                    //Debug.Log("dataFirst : " + GameManager.instance.parseJson.data.observerId);
                    //Debug.Log("dataFirst : " + GameManager.instance.parseJson.data.observerSerialNumber);
                    //Debug.Log("dataFirst : " + GameManager.instance.parseJson.data.latitude);
                    //Debug.Log("dataFirst : " + GameManager.instance.parseJson.data.longitude);
                }
                else
                {
                    Debug.Log("Error: " + response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                Debug.Log("Exception: " + ex.Message);
                await Task.Delay(15000);
                //StartCoroutine(GameManager.instance.WaitAndDoSomething(15));
            }
            finally
            {
                if (!GameManager.instance.isCommanding)
                {
                    GameManager.instance.getDataState = true;
                }
            }
        }

    }

    public async Task SendPostCompleteRequest()
    {
        using (HttpClient client = new HttpClient())
        {
            string t_url = node.reportUrl + GameManager.instance.parseJson.data.reportId;
            try
            {
                // POST ��û ������
                HttpResponseMessage response = await client.PostAsync(t_url, node.content);

                GameManager.instance.parseJson.data.reportId = 0;
                Debug.Log("Good transmit report");
            }
            catch (Exception ex)
            {
                Debug.Log("Exception: " + ex.Message);
            }
        }
    }
}

public class NetworkNode
{
    ParseJson command;
    public string url;
    public string reportUrl;
    static object data;
    public string jsonData;
    public StringContent content;

    public NetworkNode()
    {
        this.url = "http://j11c209.p.ssafy.io:8080/pick/get";
        this.reportUrl = "http://j11c209.p.ssafy.io:8080/pick/";
        data = new
        {
            fetchSerialNumber = "FETCHER20241010"
        };

        // ��ü�� JSON ���ڿ��� ��ȯ
        jsonData = JsonConvert.SerializeObject(data);
        content = new StringContent(jsonData, Encoding.UTF8, "application/json");
    }
}